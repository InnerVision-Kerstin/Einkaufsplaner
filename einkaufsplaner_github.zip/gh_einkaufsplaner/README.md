# Familien Einkaufsplaner

Von Kerstin Püringer, InnerVision.

Wochenplan, Rezepte und Einkaufsliste für die ganze Familie. Alle Eingaben bleiben auf dem eigenen Gerät gespeichert.
